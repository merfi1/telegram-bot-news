# main.py
from telethon import TelegramClient, events
import requests
import os

api_id = int(os.environ.get("71375"))
api_hash = os.environ.get("3e0970bf6127ec611976684a5cec921c")
channel_username = os.environ.get("caronline")  # مثال: "channelname"
target_url = os.environ.get("https://alphasoft.ir/telegram/post_sync.php")     # آدرس PHP شما برای دریافت پست‌ها

client = TelegramClient('session', api_id, api_hash)

@client.on(events.NewMessage(chats=channel_username))
async def handler(event):
    msg = event.message
    content = msg.message or ""
    media_url = None

    if msg.media:
        # فایل را موقتاً دانلود و آپلود نکن، فقط اعلام کن که رسانه هست
        content += "\n[پست دارای رسانه است]"

    # ارسال به سرور PHP شما
    try:
        requests.post(target_url, data={
            'text': content,
            'channel': channel_username
        })
    except Exception as e:
        print("خطا در ارسال:", e)

print("در حال اجرا...")
client.start()
client.run_until_disconnected()
